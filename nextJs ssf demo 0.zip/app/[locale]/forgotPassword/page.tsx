export default function Home() {
	return <div>forgot password</div>;
}
